library("lmtest")
library("car")

# Практическая работа №2.1 (Вариант 3)
# Набор данных - swiss;
# Объясняемая переменная - Examination;
# Регрессор - Fertility, Catholic, Infant.Mortality;

data = swiss

# 1. Проверьте, что в наборе данных нет линейной зависимости (построить зависимости
# между переменными, указанными в варианте, и проверить, что R^2 в каждой из них
# невысокий). В случае, если R^2 большой, один из таких столбцов можно исключить
# из рассмотрения.

# Проверим зависимость регрессоров (Fertility, Catholic, Infant.Mortality) между собой

# способ 1:
model_ferCInf = lm(Fertility~Catholic + Infant.Mortality, data) 
summary(model_ferCInf) # R^2 = 30% -> нет зависимости

model_CatInfF = lm(Catholic~Infant.Mortality + Fertility, data)
summary(model_CatInfF) # R^2 = 18% -> нет зависимости

model_InfFC = lm(Infant.Mortality~Fertility + Catholic, data)
summary(model_InfFC) # R^2 = 14% -> нет зависимости

# 2 способ:
model_ex = lm(Examination~Fertility + Catholic + Infant.Mortality, data) 
vif(model_ex) # Fer - 1.49, Cat - 1.27, Inf - 1.21 -> VIF < 10 -> связи между регрессорами нет

# 2. Постройте линейную модель зависимой переменной от указанных в варианте
# регрессоров по методу наименьших квадратов (команда lm пакета lmtest в языке R).
# Оценить, насколько хороша модель, согласно: 1) R^2 , 2) p-значениям каждого коэф.

model_ex = lm(Examination~Fertility + Catholic + Infant.Mortality, data)
vif(model_ex)
summary(model_ex) # 1) R^2 = 51% -> модель относительно хороша; 2) p-value Infant.Mortality -
# - большой (0.12093), звёздочек нет -> можем попробовать убрать этот регрессор и проверить 
# как изменился R^2

# Проведём эксперимент по исключению регрессора:
model_ex_new = lm(Examination~Fertility + Catholic, data)
vif(model_ex_new) # невысокий
summary(model_ex_new) # R^2 = 49% -> коэф. детерминации не сильно изменился, можно исключить 
                      # регрессор Infant.Mortality.


# 3. Введите в модель логарифмы регрессоров (если возможно). Сравнить модели и
# выбрать наилучшую.

# модель с log(Fertility):
model_ex_logF = lm(Examination~Fertility + Catholic + Infant.Mortality + log(Fertility), data)
vif(model_ex_logF) # Fertility = 61.4 и log(Fertility) = 56.3 | > 10
summary(model_ex_logF) # R^2 = 53%, звезд мало - модель плоха

# модель с log(Catholic):
model_ex_logC = lm(Examination~Fertility + Catholic + Infant.Mortality + log(Catholic), data)
vif(model_ex_logC) # Catholic =12.7 и log(Catholic) = 11.4 | > 10
summary(model_ex_logC) # R^2 = 55%, звёзд много - модель хороша

# модель с log(Infant.Mortality):
model_ex_logInf = lm(Examination~Fertility + Catholic + Infant.Mortality + log(Infant.Mortality), data)
vif(model_ex_logInf) # Infant.Mortality = 50.3 и log(Infant.Mortality) = 49.7 | > 10
summary(model_ex_logInf) # R^2 = 53%, звезды есть - модель относительно хороша

# лучшая модель model_ex_logC с log(Catholic).

# 4. Введите в модель всевозможные произведения пар регрессоров, в том числе квадраты
# регрессоров. Найдите одну или несколько наилучших моделей по доле объяснённого разброса
# в данных R^2.

model_ex_IF = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Fertility^2), data)
vif(model_ex_IF) 
summary(model_ex_IF) # R^2 = 53%

model_ex_IC = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Catholic^2), data)
vif(model_ex_IC)
summary(model_ex_IC) # R^2 = 52%

model_ex_IInf = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Infant.Mortality^2), data)
vif(model_ex_IInf)
summary(model_ex_IInf) # R^2 = 52%

model_ex_FC = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Fertility*Catholic), data)
vif(model_ex_FC)
summary(model_ex_FC) # R^2 = 57%

model_ex_CInf = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Catholic*Infant.Mortality), data)
vif(model_ex_CInf)
summary(model_ex_CInf) # R^2 = 54%

model_ex_InfF = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Infant.Mortality*Fertility), data)
vif(model_ex_InfF)
summary(model_ex_InfF) # R^2 = 55%

# лучшая модель:
model_ex_FC = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Fertility*Catholic), data)
vif(model_ex_FC)
summary(model_ex_FC)
# R^2 = 57% - наилучший показатель среди остальных моделей, где также
# у каждого регрессора есть звёзды.


# Практическая работа №2.2 (Вариант 3)
# Набор данных - swiss;
# Объясняемая переменная - Examination;
# Регрессор - Fertility, Catholic, Infant.Mortality;

# 1. Доверительные интервалы для всех коэффициентов в модели, p = 95%.
model_ex_FC = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Fertility*Catholic), data)
vif(model_ex_FC)
summary(model_ex_FC)
t_critical = qt(0.975, df = 42) # кол-во степеней свободы = число примеров(47) - число коэф.(5)
t_critical # 2.02

#Рассчитаем дов. интервал с вероятностью p = 95% для коэффициента перед
#свободным коэф. Середина интервала – 55.26. Стандартная ошибка – 9.85.

# free_coefficient: [55.26 - 2.02 * 9.85, 55.26 + 2.02 * 9.85] = [35.36, 75.16];
# Fertility: [-0.71 - 2.02 * 0.15, -0.71 + 2.02 * 0.15] = [-0.91, -0.41];
# Catholic: [-0.53 - 2.02 * 0.18, -0.53 + 2.02 * 0.18] = [-0.89, -0.17];
# Infant.Mortality: [0.66 - 2.02 * 0.30, 0.66 + 2.02 * 0.30] = [0.05, 1.27];
# I(Fertility*Catholic): [0.01 - 2.02 * 0.002, 0.01 + 2.02 * 0.002] = [0.006, 0.01];

# 2. Сделайте вывод о отвержении или невозможности отвергнуть статистическую гипотезу о 
# том, что коэффициент равен 0.

# free_coefficient: [35.36, 75.16] - 0 не попадает в интервал -> Отвергаем гипотезу о том,
# что этот коэффициент может быть равен 0, на уровне значимости 5%.

# Fertility: [-0.91, -0.41] - 0 не попадает в интервал -> Отвергаем гипотезу о том,
# что этот коэффициент может быть равен 0, на уровне значимости 5%.

# Catholic: [-0.89, -0.17] - 0 не попадает в интервал -> Отвергаем гипотезу о том,
# что этот коэффициент может быть равен 0, на уровне значимости 5%.

# Infant.Mortality: [0.05, 1.27] - 0 не попадает в интервал -> Отвергаем гипотезу о том,
# что этот коэффициент может быть равен 0, на уровне значимости 5%.

# I(Fertility*Catholic): [0.006, 0.01] - 0 не попадает в интервал -> Отвергаем гипотезу о том,
# что этот коэффициент может быть равен 0, на уровне значимости 5%.

# 3. Доверительный интервал для одного прогноза (p = 95%, набор значений
# регрессоров выбираете сами).

model_ex_FC = lm(Examination~Fertility + Catholic + Infant.Mortality + I(Fertility*Catholic), data)
new.data = data.frame(Fertility = 40, Catholic = 20, Infant.Mortality = 10, I(Fertility*Catholic) = 30)
predict(model_ex_FC, new.data, interval = "confidence") 
# прогноз = 27.84

