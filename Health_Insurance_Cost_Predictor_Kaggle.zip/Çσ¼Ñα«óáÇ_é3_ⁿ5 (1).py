#!/usr/bin/env python
# coding: utf-8

# ### Задание 5, вариант 3, тема 20

# Подключаем необходимые библиотеки:

# In[10]:


import pandas
import numpy as np
import matplotlib.pyplot as plt


# Используем набор данных: Medical Cost Personal Datasets (Медицинские расходы Персональные наборы данных)

# In[14]:


data = pandas.read_csv('C:\\Users\\79251\\Downloads\\insurance.csv')


# 1. Сколько в датасете объектов и признаков? Дать описание каждому признаку, если оно есть.
# 
# Смотрим размер таблицы:

# In[5]:


data.shape


# Таблица содержит 1338 строк (объектов) и 7 столбцов (признаков)
# 
# Описание признаков: 
# 
# - age: возраст основного бенефициара;
# - sex: пол страховщика;
# - bmi: индекс массы тела, дающий представление о массе тела, которая относительно высока или мала по отношению к росту, объективный показатель массы тела (кг/м^2) с использованием отношения роста к весу, в идеале от 18,5 до 24,9;
# - children: количество детей, охваченных медицинским страхованием / количество иждивенцев;
# - smoker: курение;
# - region: жилой район получателя в США, северо-восток, юго-восток, юго-запад, северо-запад;
# - charges: индивидуальные медицинские расходы, оплачиваемые медицинским страхованием;
# 
# 2. Сколько категориальных признаков, какие?
# 
# В наборе 3 категориальных признака:
# - sex - 2 уникального значения (male, female);
# - smoker - 2 уникального значения (yes, no);
# - region - 4 уникальных значений (northeast, southeast, southwest, northwest);
# 
# 3. Столбец с максимальным количеством уникальных значений категориального признака?

# In[4]:


array = data['sex'].unique()
print("sex: ", len(array))


# In[5]:


array = data['smoker'].unique()
print("smoker: ", len(array))


# In[6]:


array = data['region'].unique()
print("region: ", len(array))


# region содержит 4 уникальных значения => это столбец с макс. кол-вом уникальных значений.
# 
# 4. Есть ли бинарные признаки?
# 
# Да, есть: sex и smoker.
# 
# 5. Какие числовые признаки?

# In[8]:


data.head(100)


# 4 числовых признаков: age, bmi, children, charges
# 
# 6. Есть ли пропуски?

# In[21]:


data.info()


# Пропусков нет.
# 
# 7. Сколько объектов с пропусками?
# 
# 0
# 
# 8. Столбец с максимальным количеством пропусков?
# 
# Такого нет.
# 
# 9. Есть ли на ваш взгляд выбросы, аномальные значения?

# In[22]:


data.describe()


# Заметный выброс наблюдается у признака charges: это видно по отличию макс. значения (63770) и 2-го квартиля (75%) (16640), а также по сущ-ой разности медианы (9382) и среднего значения (13270).
# 
# 10. Столбец с максимальным средним значением после нормировки признаков через стандартное отклонение?

# In[7]:


data.describe()


# In[19]:


# Нормализуем вещетвенные переменные

from sklearn.preprocessing import StandardScaler 

scale_features_std = StandardScaler() 
features_std = scale_features_std.fit_transform(data[['age', 'bmi', 'children', 'charges']]) 

data[['age', 'bmi', 'children', 'charges']] = features_std


# In[6]:


data.head()


# In[7]:


data.describe()


# Наибольшее среднее значение у столбца children - 2.721623e-17

# In[20]:


# Обработаем категориальные признаки

from sklearn.preprocessing import LabelEncoder
label = LabelEncoder()
label.fit(data.sex)
data.sex = label.transform(data.sex)

label.fit(data.smoker)
data.smoker = label.transform(data.smoker)

label.fit(data.region)
data.region = label.transform(data.region)


# In[9]:


data.head()


# 11. Столбец с целевым признаком?
# 
# В качестве целевого признака выбран столбец smoker, т.к. его можно спрогнозировать с помощью остальных признаков.
# 
# 12. Сколько объектов попадает в тренировочную выборку при использовании train_test_split с параметрами test_size = 0.3, random_state = 42?

# In[10]:


from sklearn.model_selection import train_test_split
train = data
target = data.charges
X_train, X_test, y_train, y_test = train_test_split(train, target, test_size = 0.3, random_state=42)
N_train, _ = X_train.shape
N_test, _ = X_test.shape
print (N_train, N_test)


# 936 объектов попадает в тренировочную выборку при использовании train_test_split с параметрами test_size=0.3,random_state=42.
# 
# 13. Между какими признаками наблюдается линейная зависимость (корреляция)?

# In[11]:


import seaborn as sns 

plt.figure(figsize=(12,10), dpi= 80)
sns.heatmap(data.corr(), xticklabels=data.corr().columns, yticklabels=data.corr().columns, cmap="RdYlGn",center=0,annot=True)

plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.show()


# Линейная зависимость наблюдается между параметрами smoker и charges, и также стоит отметить не сильную, но все же корреляцию между charges и age.
# 
# 14. Сколько признаков достаточно для объяснения 90% дисперсии после применения метода PCA?
# 15. Какой признак вносит наибольший вклад в первую компоненту?

# In[12]:


from sklearn.decomposition import PCA
get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt


# In[13]:


pca = PCA()
X_train=X_train.dropna()
X_train
X_pca = pca.fit(X_train)


# In[14]:


for i, component in enumerate(pca.components_):
    print("{} component: {}% of initial variance".format(i + 1, 
          round(100 * pca.explained_variance_ratio_[i], 2)))
    print(" + ".join("%.3f x %s" % (value, name)
                     for value, name in zip(component,train.columns)))


# Наибольший вклад в первую компоненту вносит признак charges, т.к у него самый большой коэф. по модулю (0.593)

# In[15]:


plt.figure(figsize=(10,7))
plt.plot(np.cumsum(pca.explained_variance_ratio_), color='k', lw=2)
plt.axhline(0.9, c='r')
plt.axvline(3.7, c='b')


# Для описания 90% дисперсии данных достаточно 4-х компонентов.
# 
# - Доп. задание: построить двухмерное представление данных с помощью алгоритма tSNE. На сколько кластеров визуально на ваш взгляд разделяется выборка?

# In[16]:


from sklearn import datasets
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

iris_df = datasets.load_iris()
tsne1 = TSNE(learning_rate=100, random_state=60)
transformed1 = tsne1.fit_transform(iris_df.data)

x_axist1 = transformed1[:, 0]
y_axist1 = transformed1[:, 1]

plt.scatter(x_axist1, y_axist1, c=iris_df.target)
plt.show()


# Выборка визуально разделяется на 3 кластера
