# Практическая работа №3.

library("lmtest")
library("rlms")
library("dplyr")
library("car")
library("GGally")
library("sandwich")

data <- rlms_read("C:\\Users\\79251\\Downloads\\r21i_os26c.sav")
glimpse(data)
data2 = select(data, status, q_marst,  q_educ, qh5, q_age, qj6.2, qj13.2)

#Исключаем строки с NA:
data2 = na.omit(data2)

#Зарплата с элементами нормализации
sal = as.numeric(data2$qj13.2)
sal1 = as.character(data2$qj13.2)
sal2 = lapply(sal1, as.integer)
sal = as.numeric(unlist(sal2))
data2["salary"] = (sal - mean(sal)) / sqrt(var(sal))

#Возраст с элементами нормализации
age1 = as.numeric(data2$q_age)
age2 = as.character(data2$q_age)
age3 = lapply(age2, as.integer)
age1 = as.numeric(unlist(age3))
mean(data2$q_age)
data2["age"] = (age1 - mean(age1)) / sqrt(var(age1))

#Продолжительность рабочей недели с элементами нормализации
hour1 = as.numeric(data2$qj6.2)
hour2 = as.character(data2$qj6.2)
hour3 = lapply(hour3, as.integer)
hour1 = as.numeric(unlist(hour3))
data2["hour"] = (hour1 - mean(hour1)) / sqrt(var(hour1))

#Пол
data2["sex"] = data2$qh5
data2$sex[which(data2$sex != "1")] <- 0
data2$sex[which(data2$sex == "1")] <- 1
data2$sex = as.numeric(data2$sex)

#Наличие высшего образования
data2["h_educ"] = data2$q_educ
data2["h_educ"] = lapply(data2["h_educ"], as.character)
data2["higher_educ"] = 0
data2$higher_educ[which(data2$h_educ == '21')] <- 1
data2$higher_educ[which(data2$h_educ == '22')] <- 1
data2$higher_educ[which(data2$h_educ == '23')] <- 1

#Наcелённый пункт
data2["city_status1"] = data2$status
data2["city_status1"] = lapply(data2["city_status1"], as.character)
data2["city_status"] = 0
data2$city_status[which(data2$city_status1 == '1')] <- 1
data2$city_status[which(data2$city_status1 == '2')] <- 1

#Семейное положение
data2["wed1"] = data2$q_marst
data2["wed1"] = lapply(data2["wed1"], as.character)
data2$wed1[which(data2$wed1 != '2')] <- 0
data2$wed1[which(data2$wed1 == '2')] <- 1
data2$wed1 = as.numeric(data2$wed1)

data2["marst1"] = data2$q_marst
data2["marst1"] = lapply(data2["marst1"], as.character)
data2["wed2"] = 0
data2$wed2[which(data2$marst1 == '4')] <- 1
data2$wed2[which(data2$marst1 == '5')] <- 1

data2["wed3"] = data2$q_marst
data2["wed3"] = lapply(data2["wed3"], as.character)
data2$wed3[which(data2$wed3 != 1)] <- 0
data2$wed3 = as.numeric(data2$wed3)

data3 = select(data2, salary, age, hour, sex, higher_educ, city_status, wed1, wed2, wed3)
data3

# 1. Постройте линейную регрессию зарплаты на все параметры, которые Вы выделили
# из данных мониторинга. Не забудьте оценить коэффициент вздутия дисперсии VIF.

model_sal = lm(salary~age + hour + sex + higher_educ + city_status + wed1 + wed2 + wed3, data = data3)
summary(model_sal)
vif(model_sal) #переменные wed коррелируют друг с другом, поэтому попробуем избавиться от wed1 и wed2 переменных
#и посмотреть на изменения

model_new = lm(salary~age + hour + sex + higher_educ + city_status + wed3, data = data3)
summary(model_new)
vif(model_new)#теперь vif в норме, модель улучшена

# 2. Поэкспериментируйте с функциями вещественных параметров: используйте
# логарифм и степени (хотя бы от 0.1 до 2 с шагом 0.1).

model1 = lm(salary~age + hour + sex + higher_educ + city_status + wed3 + I(hour^1.8), data = data3)
summary(model1)
vif(model1)

model2 = lm(salary~age + hour + sex + higher_educ + city_status + wed3 + log(age), data = data3)
summary(model2)
vif(model2)

model3 = lm(salary~age + hour + sex + higher_educ + city_status + wed3 + log(hour) + I(age^2), data = data3)
summary(model3)
vif(model3)

model4 = lm(salary~age + hour + sex + higher_educ + city_status + wed3 + I(age^2), data = data3)
summary(model4)
vif(model4)

model5 = lm(salary~age + hour + sex + higher_educ + city_status + wed3 + log(hour), data = data3)
summary(model5)
vif(model5)

model6 = lm(salary~age + hour + sex + higher_educ + city_status + wed3 + log(age) + I(hour^1.8), data = data3)
summary(model6)
vif(model6)

# 3. Выделите наилучшие модели из построенных: по значимости параметров,
# включённых в зависимости, и по объяснённому с помощью построенных зависимостей разбросу adjusted R2.

summary(model1) # у каждого параметра есть звёздочки, R^2 = 18%
vif(model1)
summary(model2) # у параметров wed3 и log(age) нет звёзд, R^2 = 16.5%
vif(model2)
summary(model3) # у параметров wed3 и log(hour) нет звёзд, R^2 = 19.4%
vif(model3)
summary(model4) # у параметра wed3 нет звёзд,  R^2 = 18.2%
vif(model4)
summary(model5) # у параметра log(hour) нет звёзд, R^2 = 17.7%
vif(model5)
summary(model6) # у параметров wed3 и log(age), и (intercept) нет звёзд, R^2 = 18.4%
vif(model6)

# наилучшие модели 
model1
model4

# 4. Сделайте вывод о том, какие индивиды получают наибольшую зарплату.
summary(model_new)
model_new
# higher_educ, city_status, hour положительно связаны с зарплатой, когда как age, sex, wed3 - отрицательно.
# Можно сказать, что чем больше длительность рабочего дня, тем больше зарплата у индивида, а также наличие высшего образования и проживание в городе.

# 5. Оцените регрессии для подмножества индивидов, указанных в варианте.
data4 = subset(data3,(wed1 == 1)&(city_status == 0))
data4

model1_1_new = lm(data = data4, salary~age + hour + sex + higher_educ + I(hour^1.8))
summary(model1_1_new)# звёзды есть у всех регрессоров, R^2 = 19%
vif(model1_1_new)# связи между регрессорами нет

data5 = subset(data3,((wed2 == 1) || (wed3 == 1)) & (city_status == 1))
data5

model1_new = lm(data = data5, salary~age + hour + sex + higher_educ  + I(hour^1.8))
summary(model1_new)# не у всех регрессоров есть звезды, R^2 = 14.8% 
vif(model1_new) # высокое значение у hour и I(hour^1.8)

# Была взята одна из лучших моделей из основной части работы, но были индивидуально удалены регрессоры, 
# которые в команде summary() выдавали NA.
