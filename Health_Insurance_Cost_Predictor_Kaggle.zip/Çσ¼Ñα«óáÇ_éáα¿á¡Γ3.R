  library("lmtest")

data = swiss

#1 Оцените среднее значение, дисперсию и СКО переменных, указанных во втором и
#третьем столбце.
# Agriculture - объесняемая переменная
# Examination, Infant.Mortality - регрессор

#1.1 оцениваем среднее значение
#суммЫ всех значений переменных
sum(data$Agriculture) # 2381
sum(data$Examination) # 775
sum(data$Infant.Mortality) # 937.3
#кол-во значений в переменных
data$Agriculture # 47
data$Examination # 47
data$Infant.Mortality #47
#вычисляем среднее арифметическое
sum(data$Agriculture)/47 # 50.66
sum(data$Examination)/47 # 16.49
sum(data$Infant.Mortality)/47 # 19.94
#проверяем вычисления с помощью команды R
mean(data$Agriculture) # 50.66
mean(data$Examination) # 16.49
mean(data$Infant.Mortality) # 19.94
#(самостоятельное вычисление среднего значения совпадает со значением при помощи команды R)

#1.2 оцениваем дисперсию и СКО переменных
var(data$Agriculture) # 515.8 - величина с большим разбросом значений
var(data$Examination) # 63.65 - величина с большим разбросом значений
var(data$Infant.Mortality) # 8.48 - величина с небольшим разбросом значений 
sd(data$Agriculture) # 22.71
sd(data$Examination) # 7.98
sd(data$Infant.Mortality) # 2.91 

#2 Постройте зависимость вида y = a + bx, где y – объясняемая переменная, x –
#регрессор (для каждого варианта по две зависимости).

# Agriculture - объясняемая переменная, Examination - регрессор
model_ex = lm(Agriculture~Examination, data) #Agriculture = alpha + beta * Examination
model_ex
summary(model_ex)

# Agriculture - объясняемая переменная, Infant.Mortality - регрессор
model_if = lm(Agriculture~Infant.Mortality, data) #Agriculture = alpha + Infant.Mortality * beta
model_if
summary(model_if)

#3 Оцените, насколько «хороша» модель по коэффициенту детерминации R^2
summary(model_ex) # R^2 = 47% модель относительно хороша: для такой
#зависимости (только одна объясняющая переменная) коэффициент очень высок, но для
#полного описания процесса нужно добавлять другие параметры.
summary(model_if) # R^2 = 0.4% < 30%. Модель плоха.
#Возможно, нужно строить другую модель, а не редактировать эту. Зависимости нет.

# 4 Оцените, есть ли взаимосвязь между объясняемой переменной и объясняющей
# переменной (по значению p-статистики, «количеству звездочек» у регрессора в
# модели).
summary(model_ex) # сильная взаимосвязь(***), Agriculture зависит от Examination 
summary(model_if) # причинно-следственной связи между Agriculture и Infant.Mortality нет, т.к. p-value: 0.6845 выше 0.5
